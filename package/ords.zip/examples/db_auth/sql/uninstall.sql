drop user SAMPLE_PLSQL_APP cascade;
drop user EXAMPLE_USER1 cascade;
drop user EXAMPLE_USER2 cascade;

quit
